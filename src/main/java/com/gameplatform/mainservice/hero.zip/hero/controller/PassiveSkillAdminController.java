package com.gameplatform.mainservice.hero.controller;

import com.gameplatform.mainservice.hero.dto.request.PassiveSkillCreateRequest;
import com.gameplatform.mainservice.hero.dto.request.PassiveSkillUpdateRequest;
import com.gameplatform.mainservice.hero.dto.response.PassiveSkillResponse;
import com.gameplatform.mainservice.hero.facade.PassiveSkillFacade;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/admin/heroes/passive-skills")
@RequiredArgsConstructor
public class PassiveSkillAdminController {

    private final PassiveSkillFacade facade;

    @GetMapping
    public ResponseEntity<List<PassiveSkillResponse>> getAll() {
        return ResponseEntity.ok(facade.getAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<PassiveSkillResponse> getById(@PathVariable Long id) {
        return ResponseEntity.ok(facade.getById(id));
    }

    @PostMapping
    public ResponseEntity<PassiveSkillResponse> create(@RequestBody @Valid PassiveSkillCreateRequest request) {
        return ResponseEntity.ok(facade.create(request));
    }

    @PutMapping("/{id}")
    public ResponseEntity<PassiveSkillResponse> update(
            @PathVariable Long id,
            @RequestBody @Valid PassiveSkillUpdateRequest request
    ) {
        return ResponseEntity.ok(facade.update(id, request));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        facade.delete(id);
        return ResponseEntity.noContent().build();
    }
}