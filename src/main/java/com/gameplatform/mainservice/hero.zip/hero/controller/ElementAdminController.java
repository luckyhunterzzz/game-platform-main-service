package com.gameplatform.mainservice.hero.controller;

import com.gameplatform.mainservice.hero.dto.request.ElementCreateRequest;
import com.gameplatform.mainservice.hero.dto.request.ElementUpdateRequest;
import com.gameplatform.mainservice.hero.dto.response.ElementResponse;
import com.gameplatform.mainservice.hero.facade.ElementFacade;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/admin/heroes/elements")
@RequiredArgsConstructor
public class ElementAdminController {

    private final ElementFacade elementFacade;

    @GetMapping
    public ResponseEntity<List<ElementResponse>> getAll() {
        return ResponseEntity.ok(elementFacade.getAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<ElementResponse> getById(@PathVariable Long id) {
        return ResponseEntity.ok(elementFacade.getById(id));
    }

    @PostMapping
    public ResponseEntity<ElementResponse> create(@RequestBody @Valid ElementCreateRequest request) {
        return ResponseEntity.ok(elementFacade.create(request));
    }

    @PutMapping("/{id}")
    public ResponseEntity<ElementResponse> update(
            @PathVariable Long id,
            @RequestBody @Valid ElementUpdateRequest request
    ) {
        return ResponseEntity.ok(elementFacade.update(id, request));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        elementFacade.delete(id);
        return ResponseEntity.noContent().build();
    }
}