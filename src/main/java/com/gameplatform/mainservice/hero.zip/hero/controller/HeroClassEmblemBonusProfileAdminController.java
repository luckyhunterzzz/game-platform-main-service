package com.gameplatform.mainservice.hero.controller;

import com.gameplatform.mainservice.hero.dto.request.HeroClassEmblemBonusProfileCreateRequest;
import com.gameplatform.mainservice.hero.dto.request.HeroClassEmblemBonusProfileUpdateRequest;
import com.gameplatform.mainservice.hero.dto.response.HeroClassEmblemBonusProfileResponse;
import com.gameplatform.mainservice.hero.facade.HeroClassEmblemBonusProfileFacade;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/admin/heroes/emblem-profiles")
@RequiredArgsConstructor
public class HeroClassEmblemBonusProfileAdminController {

    private final HeroClassEmblemBonusProfileFacade facade;

    @GetMapping
    public ResponseEntity<List<HeroClassEmblemBonusProfileResponse>> getAll() {
        return ResponseEntity.ok(facade.getAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<HeroClassEmblemBonusProfileResponse> getById(@PathVariable Long id) {
        return ResponseEntity.ok(facade.getById(id));
    }

    @PostMapping
    public ResponseEntity<HeroClassEmblemBonusProfileResponse> create(
            @RequestBody @Valid HeroClassEmblemBonusProfileCreateRequest request
    ) {
        return ResponseEntity.ok(facade.create(request));
    }

    @PutMapping("/{id}")
    public ResponseEntity<HeroClassEmblemBonusProfileResponse> update(
            @PathVariable Long id,
            @RequestBody @Valid HeroClassEmblemBonusProfileUpdateRequest request
    ) {
        return ResponseEntity.ok(facade.update(id, request));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        facade.delete(id);
        return ResponseEntity.noContent().build();
    }
}