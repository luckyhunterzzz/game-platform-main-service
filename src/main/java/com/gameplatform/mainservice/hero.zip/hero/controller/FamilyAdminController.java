package com.gameplatform.mainservice.hero.controller;

import com.gameplatform.mainservice.hero.dto.request.FamilyCreateRequest;
import com.gameplatform.mainservice.hero.dto.request.FamilyUpdateRequest;
import com.gameplatform.mainservice.hero.dto.response.FamilyResponse;
import com.gameplatform.mainservice.hero.facade.FamilyFacade;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/admin/heroes/families")
@RequiredArgsConstructor
public class FamilyAdminController {

    private final FamilyFacade familyFacade;

    @GetMapping
    public ResponseEntity<List<FamilyResponse>> getAll() {
        return ResponseEntity.ok(familyFacade.getAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<FamilyResponse> getById(@PathVariable Long id) {
        return ResponseEntity.ok(familyFacade.getById(id));
    }

    @PostMapping
    public ResponseEntity<FamilyResponse> create(@RequestBody @Valid FamilyCreateRequest request) {
        return ResponseEntity.ok(familyFacade.create(request));
    }

    @PutMapping("/{id}")
    public ResponseEntity<FamilyResponse> update(
            @PathVariable Long id,
            @RequestBody @Valid FamilyUpdateRequest request
    ) {
        return ResponseEntity.ok(familyFacade.update(id, request));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        familyFacade.delete(id);
        return ResponseEntity.noContent().build();
    }
}