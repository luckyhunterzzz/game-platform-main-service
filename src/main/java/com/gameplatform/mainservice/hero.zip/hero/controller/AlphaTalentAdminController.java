package com.gameplatform.mainservice.hero.controller;

import com.gameplatform.mainservice.hero.dto.request.AlphaTalentCreateRequest;
import com.gameplatform.mainservice.hero.dto.request.AlphaTalentUpdateRequest;
import com.gameplatform.mainservice.hero.dto.response.AlphaTalentResponse;
import com.gameplatform.mainservice.hero.facade.AlphaTalentFacade;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/admin/heroes/alpha-talents")
@RequiredArgsConstructor
public class AlphaTalentAdminController {

    private final AlphaTalentFacade facade;

    @GetMapping
    public ResponseEntity<List<AlphaTalentResponse>> getAll() {
        return ResponseEntity.ok(facade.getAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<AlphaTalentResponse> getById(@PathVariable Long id) {
        return ResponseEntity.ok(facade.getById(id));
    }

    @PostMapping
    public ResponseEntity<AlphaTalentResponse> create(@RequestBody @Valid AlphaTalentCreateRequest request) {
        return ResponseEntity.ok(facade.create(request));
    }

    @PutMapping("/{id}")
    public ResponseEntity<AlphaTalentResponse> update(
            @PathVariable Long id,
            @RequestBody @Valid AlphaTalentUpdateRequest request
    ) {
        return ResponseEntity.ok(facade.update(id, request));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        facade.delete(id);
        return ResponseEntity.noContent().build();
    }
}