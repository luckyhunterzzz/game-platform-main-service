package com.gameplatform.mainservice.hero.controller;

import com.gameplatform.mainservice.hero.dto.request.RarityCreateRequest;
import com.gameplatform.mainservice.hero.dto.request.RarityUpdateRequest;
import com.gameplatform.mainservice.hero.dto.response.RarityResponse;
import com.gameplatform.mainservice.hero.facade.RarityFacade;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/admin/heroes/rarities")
@RequiredArgsConstructor
public class RarityAdminController {

    private final RarityFacade rarityFacade;

    @GetMapping
    public ResponseEntity<List<RarityResponse>> getAll() {
        return ResponseEntity.ok(rarityFacade.getAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<RarityResponse> getById(@PathVariable Long id) {
        return ResponseEntity.ok(rarityFacade.getById(id));
    }

    @PostMapping
    public ResponseEntity<RarityResponse> create(@RequestBody @Valid RarityCreateRequest request) {
        return ResponseEntity.ok(rarityFacade.create(request));
    }

    @PutMapping("/{id}")
    public ResponseEntity<RarityResponse> update(
            @PathVariable Long id,
            @RequestBody @Valid RarityUpdateRequest request
    ) {
        return ResponseEntity.ok(rarityFacade.update(id, request));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        rarityFacade.delete(id);
        return ResponseEntity.noContent().build();
    }
}